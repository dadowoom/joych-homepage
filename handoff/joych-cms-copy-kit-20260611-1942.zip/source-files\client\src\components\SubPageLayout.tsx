/**
 * SubPageLayout — 하위 페이지 공통 레이아웃
 * SiteHeader(공통 헤더) + 브레드크럼 + 좌측 사이드 메뉴 + 푸터
 * 모든 동적 페이지(/page/item/:id, /page/sub/:id)에서 사용
 *
 * ⚠️ 헤더는 SiteHeader 컴포넌트를 재사용합니다.
 *    App.tsx에서 이미 <SiteHeader />를 렌더링하므로 여기서는 중복 렌더링하지 않습니다.
 */
import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { ChevronDown, ChevronRight, Home } from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663470178900/KASTcRBzh5rwhJEekrJN6E/church-logo_35c62cc5.jpg";
const CHURCH_ADDRESS = "경상북도 포항시 북구 삼흥로 411";

function getChurchAddress(address?: string | null) {
  const value = address?.trim();
  if (!value || value.includes("상통로 411")) {
    return CHURCH_ADDRESS;
  }
  return value;
}

type SideMenuItem = {
  id: number;
  label: string;
  href: string | null;
  isActive?: boolean;
  subItems?: SideMenuItem[];
};

interface SubPageLayoutProps {
  /** 현재 페이지 제목 (브레드크럼 마지막 항목) */
  pageTitle: string;
  /** 상위 메뉴 이름 (브레드크럼 중간 항목) */
  parentLabel?: string;
  /** 상위 메뉴 href */
  parentHref?: string;
  /** 사이드 메뉴에 표시할 같은 카테고리 항목들 */
  sideMenuItems?: SideMenuItem[];
  /** 페이지 본문 */
  children: React.ReactNode;
}

export default function SubPageLayout({
  pageTitle,
  parentLabel,
  parentHref,
  sideMenuItems = [],
  children,
}: SubPageLayoutProps) {
  const { data: dbSettings } = trpc.home.settings.useQuery();
  const [openSideMenuIds, setOpenSideMenuIds] = useState<Set<number>>(new Set());
  const activeSideMenuIds = useMemo(
    () =>
      sideMenuItems
        .filter((item) => item.isActive || item.subItems?.some((subItem) => subItem.isActive))
        .map((item) => item.id),
    [sideMenuItems]
  );
  const activeSideMenuKey = activeSideMenuIds.join(",");

  useEffect(() => {
    if (!activeSideMenuKey) return;
    const activeIds = activeSideMenuKey.split(",").map((id) => Number(id));
    setOpenSideMenuIds((previous) => {
      const next = new Set(previous);
      let changed = false;
      activeIds.forEach((id) => {
        if (!next.has(id)) {
          next.add(id);
          changed = true;
        }
      });
      return changed ? next : previous;
    });
  }, [activeSideMenuKey]);

  const toggleSideMenu = (itemId: number) => {
    setOpenSideMenuIds((previous) => {
      const next = new Set(previous);
      if (next.has(itemId)) {
        next.delete(itemId);
      } else {
        next.add(itemId);
      }
      return next;
    });
  };

  const socialLinks = [
    { icon: "fab fa-youtube", label: "유튜브", href: dbSettings?.youtube_url || "/worship/tv" },
    { icon: "fab fa-facebook-f", label: "페이스북", href: dbSettings?.facebook_url || null },
    { icon: "fab fa-instagram", label: "인스타그램", href: dbSettings?.instagram_url || null },
  ];

  return (
    <div className="min-h-screen bg-[#FAFAF8] flex flex-col" style={{ fontFamily: "'Noto Sans KR', sans-serif" }}>

      {/* ===== 브레드크럼 ===== */}
      <div className="bg-white border-b border-gray-100">
        <div className="container py-3">
          <nav className="flex items-center gap-1.5 text-sm text-gray-500">
            <Link href="/" className="flex items-center gap-1 hover:text-[#1B5E20] transition-colors">
              <Home className="w-3.5 h-3.5" />
              <span>홈</span>
            </Link>
            {parentLabel && (
              <>
                <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
                {parentHref ? (
                  <Link href={parentHref} className="hover:text-[#1B5E20] transition-colors">{parentLabel}</Link>
                ) : (
                  <span>{parentLabel}</span>
                )}
              </>
            )}
            <ChevronRight className="w-3.5 h-3.5 text-gray-300" />
            <span className="text-[#1B5E20] font-medium">{pageTitle}</span>
          </nav>
        </div>
      </div>

      {/* ===== 본문 영역 ===== */}
      <div className="flex-1">
        <div className="container py-8 md:py-12">
          <div className="flex gap-8">

            {/* 좌측 사이드 메뉴 (같은 카테고리 항목들) */}
            {sideMenuItems.length > 0 && (
              <aside className="hidden md:block w-52 shrink-0">
                {parentLabel && (
                  <div className="bg-[#1B5E20] text-white text-sm font-bold px-4 py-3 rounded-t-lg">
                    {parentLabel}
                  </div>
                )}
                <ul className="border border-gray-200 rounded-b-lg overflow-hidden">
                  {sideMenuItems.map((item) => {
                    const hasSubItems = Boolean(item.subItems?.length);
                    const isOpen = openSideMenuIds.has(item.id);

                    return (
                      <li key={item.id}>
                        {hasSubItems && item.href ? (
                          <div
                            className={`flex items-stretch border-b border-gray-100 last:border-0 transition-colors ${
                              item.isActive
                                ? "bg-[#F1F8E9] text-[#1B5E20] font-semibold"
                                : "text-gray-600 hover:bg-[#F1F8E9] hover:text-[#1B5E20]"
                            }`}
                          >
                            <Link
                              href={item.href}
                              className="flex min-w-0 flex-1 items-center px-4 py-3 text-sm"
                            >
                              <span className="truncate">{item.label}</span>
                            </Link>
                            <button
                              type="button"
                              aria-expanded={isOpen}
                              onClick={() => toggleSideMenu(item.id)}
                              className="flex w-10 shrink-0 items-center justify-center text-gray-400 hover:text-[#1B5E20]"
                              aria-label={`${item.label} 하위 메뉴 열기`}
                            >
                              {isOpen ? (
                                <ChevronDown className="w-3.5 h-3.5 shrink-0" />
                              ) : (
                                <ChevronRight className="w-3.5 h-3.5 shrink-0" />
                              )}
                            </button>
                          </div>
                        ) : hasSubItems ? (
                          <button
                            type="button"
                            aria-expanded={isOpen}
                            onClick={() => toggleSideMenu(item.id)}
                            className={`flex w-full items-center justify-between gap-2 px-4 py-3 text-left text-sm border-b border-gray-100 last:border-0 transition-colors ${
                              item.isActive
                                ? "bg-[#F1F8E9] text-[#1B5E20] font-semibold"
                                : "text-gray-600 hover:bg-[#F1F8E9] hover:text-[#1B5E20]"
                            }`}
                          >
                            <span>{item.label}</span>
                            {isOpen ? (
                              <ChevronDown className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                            ) : (
                              <ChevronRight className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                            )}
                          </button>
                        ) : item.href ? (
                          <Link
                            href={item.href}
                            className={`block px-4 py-3 text-sm border-b border-gray-100 last:border-0 transition-colors ${
                              item.isActive
                                ? "bg-[#F1F8E9] text-[#1B5E20] font-semibold"
                                : "text-gray-600 hover:bg-[#F1F8E9] hover:text-[#1B5E20]"
                            }`}
                          >
                            {item.label}
                          </Link>
                        ) : (
                          <span
                            className={`block px-4 py-3 text-sm border-b border-gray-100 last:border-0 ${
                              item.isActive
                                ? "bg-[#F1F8E9] text-[#1B5E20] font-semibold"
                                : "text-gray-400"
                            }`}
                          >
                            {item.label}
                          </span>
                        )}
                        {hasSubItems && isOpen && (
                          <ul className="bg-white border-t border-gray-100">
                            {item.subItems?.map((subItem) => (
                              <li key={subItem.id}>
                                {subItem.href ? (
                                  <Link
                                    href={subItem.href}
                                    className={`block py-2.5 pl-7 pr-4 text-xs border-b border-gray-100 last:border-0 transition-colors ${
                                      subItem.isActive
                                        ? "bg-[#F1F8E9] text-[#1B5E20] font-semibold"
                                        : "text-gray-500 hover:bg-[#F1F8E9] hover:text-[#1B5E20]"
                                    }`}
                                  >
                                    {subItem.label}
                                  </Link>
                                ) : (
                                  <span
                                    className={`block py-2.5 pl-7 pr-4 text-xs border-b border-gray-100 last:border-0 ${
                                      subItem.isActive
                                        ? "bg-[#F1F8E9] text-[#1B5E20] font-semibold"
                                        : "text-gray-400"
                                    }`}
                                  >
                                    {subItem.label}
                                  </span>
                                )}
                              </li>
                            ))}
                          </ul>
                        )}
                      </li>
                    );
                  })}
                </ul>
              </aside>
            )}

            {/* 메인 콘텐츠 */}
            <main className="flex-1 min-w-0">
              {/* 페이지 제목 */}
              <h1
                className="text-2xl md:text-3xl font-bold text-gray-900 mb-6 pb-4 border-b-2 border-[#1B5E20]"
                style={{ fontFamily: "'Noto Serif KR', serif" }}
              >
                {pageTitle}
              </h1>
              {children}
            </main>

          </div>
        </div>
      </div>

      {/* ===== 푸터 ===== */}
      <footer className="bg-[#0F172A] text-gray-400 py-6 mt-auto">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 items-center">
            <div>
              <div className="inline-flex rounded-md bg-white px-3 py-2">
                <img
                  src={LOGO_URL}
                  alt="기쁨의교회"
                  className="h-8 w-auto object-contain"
                />
              </div>
              <p className="mt-2 text-xs text-gray-600">since 1946 대한예수교장로회</p>
            </div>
            <div className="space-y-1.5 text-sm">
              <p className="flex items-center gap-2">
                <i className="fas fa-map-marker-alt text-[#4CAF50] w-4"></i>
                {getChurchAddress(dbSettings?.address)}
              </p>
              <p className="flex items-center gap-2">
                <i className="fas fa-phone text-[#4CAF50] w-4"></i>
                TEL : {dbSettings?.tel ?? "054) 270-1000"} &nbsp;|&nbsp; FAX : {dbSettings?.fax ?? "054) 270-1005"}
              </p>
              <p className="text-xs text-gray-500 mt-3">
                Copyright &copy; {new Date().getFullYear()} 기쁨의교회 All rights reserved.
              </p>
            </div>
            <div className="flex gap-3 md:justify-end">
              {socialLinks.map((s, i) => (
                s.href ? (
                  <a
                    key={i}
                    href={s.href}
                    target={s.href.startsWith("http") ? "_blank" : undefined}
                    rel={s.href.startsWith("http") ? "noopener noreferrer" : undefined}
                    aria-label={s.label}
                    className="w-9 h-9 rounded-full border border-gray-700 flex items-center justify-center text-gray-400 hover:bg-[#1B5E20] hover:border-[#1B5E20] hover:text-white transition-colors text-sm"
                  >
                    <i className={s.icon}></i>
                  </a>
                ) : (
                  <span
                    key={i}
                    aria-label={`${s.label} 링크 미등록`}
                    className="w-9 h-9 rounded-full border border-gray-700 flex items-center justify-center text-gray-500 transition-colors text-sm"
                  >
                    <i className={s.icon}></i>
                  </span>
                )
              ))}
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
}
