/**
 * 교회 회원(교적부) DB 함수 (server/db/member.ts)
 * ─────────────────────────────────────────────────────────────────────────────
 * 담당 기능:
 *   - 선택지 관리: getMemberFieldOptions, getAllMemberFieldOptions,
 *                 createMemberFieldOption, updateMemberFieldOption, deleteMemberFieldOption
 *   - 성도 조회: getMemberByEmail, getMemberById, getAllMembers, getPendingMembers
 *   - 성도 등록/수정: createMember, updateMemberBasicInfo, updateMemberChurchInfo
 *   - 관리자 전용: adminUpdateMember, adminResetMemberPassword
 */

import { and, eq, asc, desc } from "drizzle-orm";
import type { ResultSetHeader } from "mysql2";
import {
  bulletinAdRequests,
  churchMembers,
  courseApplications,
  freeBoardPosts,
  memberFieldOptions,
  memberSocialAccounts,
  missionReportAuthors,
  missionReports,
  reservations,
  schoolPosts,
  subtitleRequests,
  testimonyComments,
  testimonyPosts,
} from "../../drizzle/schema";
import { getDb } from "./connection";

export type MemberSocialProvider = "google" | "kakao";

// ─── 선택지 관리 (직분, 부서, 구역 등 드롭다운 옵션) ─────────────────────────

/** 선택지 목록 조회 (fieldType별, 활성만) */
export async function getMemberFieldOptions(fieldType?: string) {
  const db = await getDb();
  if (!db) return [];
  if (fieldType) {
    return db.select().from(memberFieldOptions)
      .where(and(
        eq(memberFieldOptions.fieldType, fieldType),
        eq(memberFieldOptions.isActive, true),
      ))
      .orderBy(asc(memberFieldOptions.sortOrder));
  }
  return db.select().from(memberFieldOptions)
    .where(eq(memberFieldOptions.isActive, true))
    .orderBy(asc(memberFieldOptions.fieldType), asc(memberFieldOptions.sortOrder));
}

/** 선택지 전체 조회 (관리자용 - 비활성 포함) */
export async function getAllMemberFieldOptions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(memberFieldOptions)
    .orderBy(asc(memberFieldOptions.fieldType), asc(memberFieldOptions.sortOrder));
}

/** 선택지 추가 */
export async function createMemberFieldOption(data: { fieldType: string; label: string; sortOrder?: number }) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');
  const [result] = await db.insert(memberFieldOptions).values({
    fieldType: data.fieldType,
    label: data.label,
    sortOrder: data.sortOrder ?? 0,
  });
  return (result as ResultSetHeader).insertId;
}

/** 선택지 수정 */
export async function updateMemberFieldOption(id: number, data: Partial<{ label: string; sortOrder: number; isActive: boolean }>) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');
  await db.update(memberFieldOptions).set(data).where(eq(memberFieldOptions.id, id));
}

/** 선택지 순서 일괄 수정 */
export async function reorderMemberFieldOptions(items: { id: number; sortOrder: number }[]) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');
  if (items.length === 0) return;

  await Promise.all(
    items.map((item) =>
      db.update(memberFieldOptions)
        .set({ sortOrder: item.sortOrder })
        .where(eq(memberFieldOptions.id, item.id))
    )
  );
}

/** 선택지 삭제 */
export async function deleteMemberFieldOption(id: number) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');
  await db.delete(memberFieldOptions).where(eq(memberFieldOptions.id, id));
}

// ─── 성도 조회 ────────────────────────────────────────────────────────────────

/** 이메일로 성도 조회 */
export async function getMemberByEmail(email: string) {
  const db = await getDb();
  if (!db) return null;
  const normalizedEmail = email.trim().toLowerCase();
  const rows = await db.select().from(churchMembers).where(eq(churchMembers.email, normalizedEmail)).limit(1);
  return rows[0] ?? null;
}

/** ID로 성도 조회 */
export async function getMemberById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(churchMembers).where(eq(churchMembers.id, id)).limit(1);
  return rows[0] ?? null;
}

/** 소셜 제공자 계정으로 성도 연결 정보 조회 */
export async function getMemberSocialAccount(provider: MemberSocialProvider, providerUserId: string) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(memberSocialAccounts)
    .where(and(
      eq(memberSocialAccounts.provider, provider),
      eq(memberSocialAccounts.providerUserId, providerUserId),
    ))
    .limit(1);
  return rows[0] ?? null;
}

/** 성도별 소셜 제공자 연결 정보 조회 */
export async function getMemberSocialAccountByMember(provider: MemberSocialProvider, memberId: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(memberSocialAccounts)
    .where(and(
      eq(memberSocialAccounts.provider, provider),
      eq(memberSocialAccounts.memberId, memberId),
    ))
    .limit(1);
  return rows[0] ?? null;
}

/** 전체 성도 목록 조회 (관리자용) */
export async function getAllMembers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(churchMembers).orderBy(desc(churchMembers.createdAt));
}

/** 승인 대기 성도 목록 */
export async function getPendingMembers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(churchMembers)
    .where(eq(churchMembers.status, 'pending'))
    .orderBy(desc(churchMembers.createdAt));
}

// ─── 성도 등록/수정 ───────────────────────────────────────────────────────────

/** 성도 회원가입 */
export async function createMember(data: {
  email?: string | null;
  passwordHash?: string | null;
  name: string;
  phone?: string;
  birthDate?: string;
  gender?: string;
  address?: string;
  emergencyPhone?: string;
  joinPath?: string;
  department?: string;
  district?: string;
  faithPlusUserId?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');
  const [result] = await db.insert(churchMembers).values({
    ...data,
    email: data.email?.trim().toLowerCase() || null,
    status: 'pending',
  });
  return (result as ResultSetHeader).insertId;
}

/** 구글/카카오 계정을 성도 계정에 연결 */
export async function createMemberSocialAccount(data: {
  memberId: number;
  provider: MemberSocialProvider;
  providerUserId: string;
  email?: string | null;
  displayName?: string | null;
  profileImageUrl?: string | null;
}) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');
  const [result] = await db.insert(memberSocialAccounts).values({
    memberId: data.memberId,
    provider: data.provider,
    providerUserId: data.providerUserId,
    email: data.email?.trim().toLowerCase() || null,
    displayName: data.displayName || null,
    profileImageUrl: data.profileImageUrl || null,
  });
  return (result as ResultSetHeader).insertId;
}

/** 성도 간편가입: 회원 생성과 소셜 계정 연결을 하나의 트랜잭션으로 처리 */
export async function createMemberWithSocialAccount(memberData: {
  email?: string | null;
  passwordHash?: string | null;
  name: string;
  phone?: string;
  birthDate?: string;
  joinPath?: string;
}, socialData: {
  provider: MemberSocialProvider;
  providerUserId: string;
  email?: string | null;
  displayName?: string | null;
  profileImageUrl?: string | null;
}) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');

  return db.transaction(async (tx) => {
    const [memberResult] = await tx.insert(churchMembers).values({
      ...memberData,
      email: memberData.email?.trim().toLowerCase() || null,
      status: 'pending',
    });
    const memberId = (memberResult as ResultSetHeader).insertId;

    await tx.insert(memberSocialAccounts).values({
      memberId,
      provider: socialData.provider,
      providerUserId: socialData.providerUserId,
      email: socialData.email?.trim().toLowerCase() || null,
      displayName: socialData.displayName || null,
      profileImageUrl: socialData.profileImageUrl || null,
    });

    return memberId;
  });
}

/** 성도 기본 정보 수정 (성도 본인) */
export async function updateMemberBasicInfo(id: number, data: Partial<{
  name: string;
  phone: string;
  birthDate: string;
  gender: string;
  address: string;
  emergencyPhone: string;
  faithPlusUserId: string;
}>) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');
  await db.update(churchMembers).set({ ...data, updatedAt: new Date() }).where(eq(churchMembers.id, id));
}

/** 성도 교회 정보 수정 (관리자 전용) */
export async function updateMemberChurchInfo(id: number, data: Partial<{
  position: string;
  department: string;
  district: string;
  baptismType: string;
  baptismDate: string;
  registeredAt: string;
  pastor: string;
  adminMemo: string;
  status: 'pending' | 'approved' | 'rejected' | 'withdrawn';
  faithPlusUserId: string;
}>) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');
  await db.update(churchMembers).set({ ...data, updatedAt: new Date() }).where(eq(churchMembers.id, id));
}

/** 성도 본인 탈퇴: 개인정보 삭제/익명화 및 소셜 연결 해제 */
export async function withdrawMemberAndErasePersonalData(id: number) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');

  const anonymizedName = "탈퇴 성도";
  const now = new Date();

  await db.transaction(async (tx) => {
    await tx.delete(memberSocialAccounts).where(eq(memberSocialAccounts.memberId, id));

    await tx.update(testimonyPosts)
      .set({ status: "deleted", updatedAt: now })
      .where(eq(testimonyPosts.authorMemberId, id));

    await tx.update(testimonyComments)
      .set({ status: "deleted", updatedAt: now })
      .where(eq(testimonyComments.authorMemberId, id));

    await tx.update(missionReports)
      .set({ authorMemberId: null, updatedAt: now })
      .where(eq(missionReports.authorMemberId, id));

    await tx.update(missionReportAuthors)
      .set({ canWrite: false, updatedAt: now })
      .where(eq(missionReportAuthors.memberId, id));

    await tx.update(schoolPosts)
      .set({ memberId: null, authorName: anonymizedName, updatedAt: now })
      .where(eq(schoolPosts.memberId, id));

    await tx.update(reservations)
      .set({ reserverName: anonymizedName, reserverPhone: null, updatedAt: now })
      .where(eq(reservations.userId, id));

    await tx.update(churchMembers)
      .set({
        email: null,
        passwordHash: null,
        name: anonymizedName,
        phone: null,
        birthDate: null,
        gender: null,
        address: null,
        emergencyPhone: null,
        joinPath: null,
        position: null,
        department: null,
        district: null,
        baptismType: null,
        baptismDate: null,
        registeredAt: null,
        pastor: null,
        adminMemo: null,
        status: "withdrawn",
        faithPlusUserId: null,
        updatedAt: now,
      })
      .where(eq(churchMembers.id, id));
  });
}

// ─── 관리자 전용 ──────────────────────────────────────────────────────────────

export type AdminHardDeleteMemberResult =
  | { deleted: true }
  | {
      deleted: false;
      reason: "not_found" | "not_withdrawn" | "has_related_records";
      related?: string[];
    };

/** 관리자: 탈퇴 상태이며 연결 기록이 없는 성도만 완전삭제 */
export async function adminHardDeleteMember(id: number): Promise<AdminHardDeleteMemberResult> {
  const db = await getDb();
  if (!db) throw new Error('DB not available');

  return db.transaction(async (tx) => {
    const [member] = await tx
      .select({ id: churchMembers.id, status: churchMembers.status })
      .from(churchMembers)
      .where(eq(churchMembers.id, id))
      .limit(1);

    if (!member) return { deleted: false, reason: "not_found" };
    if (member.status !== "withdrawn") return { deleted: false, reason: "not_withdrawn" };

    const related: string[] = [];

    if ((await tx.select({ id: freeBoardPosts.id }).from(freeBoardPosts).where(eq(freeBoardPosts.authorMemberId, id)).limit(1))[0]) {
      related.push("자유게시판");
    }
    if ((await tx.select({ id: subtitleRequests.id }).from(subtitleRequests).where(eq(subtitleRequests.memberId, id)).limit(1))[0]) {
      related.push("자막신청");
    }
    if ((await tx.select({ id: bulletinAdRequests.id }).from(bulletinAdRequests).where(eq(bulletinAdRequests.memberId, id)).limit(1))[0]) {
      related.push("주보 광고신청");
    }
    if ((await tx.select({ id: courseApplications.id }).from(courseApplications).where(eq(courseApplications.memberId, id)).limit(1))[0]) {
      related.push("강좌 신청");
    }
    if ((await tx.select({ id: reservations.id }).from(reservations).where(eq(reservations.userId, id)).limit(1))[0]) {
      related.push("시설 예약");
    }
    if ((await tx.select({ id: missionReportAuthors.id }).from(missionReportAuthors).where(eq(missionReportAuthors.memberId, id)).limit(1))[0]) {
      related.push("선교보고 권한");
    }
    if ((await tx.select({ id: missionReports.id }).from(missionReports).where(eq(missionReports.authorMemberId, id)).limit(1))[0]) {
      related.push("선교보고");
    }
    if ((await tx.select({ id: testimonyPosts.id }).from(testimonyPosts).where(eq(testimonyPosts.authorMemberId, id)).limit(1))[0]) {
      related.push("간증 게시글");
    }
    if ((await tx.select({ id: testimonyComments.id }).from(testimonyComments).where(eq(testimonyComments.authorMemberId, id)).limit(1))[0]) {
      related.push("간증 댓글");
    }
    if ((await tx.select({ id: schoolPosts.id }).from(schoolPosts).where(eq(schoolPosts.memberId, id)).limit(1))[0]) {
      related.push("교회학교 게시글");
    }

    if (related.length > 0) {
      return { deleted: false, reason: "has_related_records", related };
    }

    await tx.delete(memberSocialAccounts).where(eq(memberSocialAccounts.memberId, id));
    await tx.delete(churchMembers).where(eq(churchMembers.id, id));

    return { deleted: true };
  });
}

/** 관리자: 성도 전체 정보 수정 (기본정보 + 교회정보 통합) */
export async function adminUpdateMember(id: number, data: Partial<{
  name: string;
  phone: string;
  birthDate: string;
  gender: string;
  address: string;
  emergencyPhone: string;
  email: string;
  position: string;
  department: string;
  district: string;
  baptismType: string;
  baptismDate: string;
  registeredAt: string;
  pastor: string;
  adminMemo: string;
  status: 'pending' | 'approved' | 'rejected' | 'withdrawn';
  faithPlusUserId: string;
}>) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');
  const normalized = data.email ? { ...data, email: data.email.trim().toLowerCase() } : data;
  await db.update(churchMembers).set({ ...normalized, updatedAt: new Date() }).where(eq(churchMembers.id, id));
}

/** 관리자: 성도 비밀번호 초기화 (임시 비밀번호 설정) */
export async function adminResetMemberPassword(id: number, tempPassword: string) {
  const bcrypt = await import('bcryptjs');
  const hash = await bcrypt.hash(tempPassword, 10);
  const db = await getDb();
  if (!db) throw new Error('DB not available');
  await db.update(churchMembers).set({ passwordHash: hash, updatedAt: new Date() }).where(eq(churchMembers.id, id));
}

// ─── 성도 검색 (내부 주소록 전용) ─────────────────────────────────────────────
/**
 * 이름으로 성도 검색 (DB 쿼리 레벨에서 필터링)
 * - approved 상태인 성도만 검색
 * - 최대 20명 반환
 * - 내부 주소록에 필요한 필드만 반환 (민감 정보 제외)
 */
export async function searchMembersByName(name: string, limit = 20) {
  const db = await getDb();
  if (!db) return [];
  const { like, and, eq: eqOp } = await import("drizzle-orm");
  const results = await db
    .select({
      id: churchMembers.id,
      name: churchMembers.name,
      phone: churchMembers.phone,
      email: churchMembers.email,
      position: churchMembers.position,
      department: churchMembers.department,
      district: churchMembers.district,
      faithPlusUserId: churchMembers.faithPlusUserId,
    })
    .from(churchMembers)
    .where(
      and(
        eqOp(churchMembers.status, "approved"),
        like(churchMembers.name, `%${name}%`)
      )
    )
    .limit(limit);
  return results;
}
